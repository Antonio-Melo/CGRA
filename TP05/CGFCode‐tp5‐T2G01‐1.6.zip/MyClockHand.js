/**
 * MyClockHand
 * @constructor
 */
 function MyClockHand(scene, scaleX, scaleY, scaleZ) {
 	CGFobject.call(this,scene);

 	this.quad = new MyQuad(scene);
 	this.angle = 0;

 	this.sx = scaleX;
 	this.sy = scaleY;
 	this.sz = scaleZ;

 };

 MyClockHand.prototype = Object.create(CGFobject.prototype);
 MyClockHand.prototype.constructor = MyClockHand;


MyClockHand.prototype.display = function() {

  this.scene.rotate(this.angle, 0, 0, 1);
  this.scene.scale(this.sx, this.sy, this.sz);
  this.scene.translate(0, 0.5, 0);
  this.quad.display();
}



MyClockHand.prototype.setAngle = function(ang) {
  this.angle = -(Math.PI * ang / 180);
}