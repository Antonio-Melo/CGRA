/**
 * MyClock
 * @constructor
 */
 function MyClock(scene) {
 	CGFobject.call(this,scene);


 	this.cylinder = new MyCylinder(scene, 12, 1);
 	this.top = new MyClockTop(scene);

 	this.secsHand = new MyClockHand(scene, 0.04, 0.7, 1);
 	this.minsHand = new MyClockHand(scene, 0.06, 0.6, 1);
 	this.hoursHand = new MyClockHand(scene, 0.08, 0.4, 1);


 	this.secsHand.setAngle((360 / 60) * 45);
 	this.minsHand.setAngle((360 / 60) * 30);
 	this.hoursHand.setAngle((360 / 60) * 15);


 	this.clockAppearance = new CGFappearance(scene);
 	this.clockAppearance.loadTexture("\\resources\\images\\clock.png");
 	this.defaultAppearance = new CGFappearance(scene);


 	this.materialA = new CGFappearance(scene);
	this.materialA.setAmbient(0, 0, 0, 0.1);
	this.materialA.setDiffuse(0.1, 0.8, 0.7, 0.1);
 	this.materialA.setSpecular(1, 0.9, 1, 0.1);

 	this.materialB = new CGFappearance(scene);
	this.materialB.setAmbient(0, 0, 0, 0.1);
	this.materialB.setDiffuse(0.8, 0.1, 0.1, 0.1);
 	this.materialB.setSpecular(1, 0.1, 0.2, 0.1); 


 	this.materialC = new CGFappearance(scene);
	this.materialC.setAmbient(0, 0, 0, 0.1);
	this.materialC.setDiffuse(0.8, 0.6, 0.1, 0.1);
 	this.materialC.setSpecular(1, 0.6, 0.1, 0.1); 
 };

 MyClock.prototype = Object.create(CGFobject.prototype);
 MyClock.prototype.constructor = MyClock;




MyClock.prototype.display = function() {

	this.scene.pushMatrix();
		this.cylinder.display();
	this.scene.popMatrix();

	this.scene.pushMatrix();
		this.clockAppearance.apply();
		this.top.display();
	this.scene.popMatrix();

	this.scene.pushMatrix();
		this.materialA.apply();
		this.scene.translate(0, 0, 1.02);
		this.secsHand.display();
	this.scene.popMatrix();

	this.scene.pushMatrix();
		this.materialB.apply();
		this.scene.translate(0, 0, 1.03);
		this.minsHand.display();
	this.scene.popMatrix();


	this.scene.pushMatrix();
		this.materialC.apply();
		this.scene.translate(0, 0, 1.04);
		this.hoursHand.display();
	this.scene.popMatrix();
};




MyClock.prototype.update = function(currTime) {

	var seconds = (currTime / 1000) % 60;
	var minutes = (currTime / (1000 * 60)) % 60;
	var hours = (currTime / (1000 * 60 * 60)) % 24;

	this.secsHand.setAngle(seconds * (360 / 60));
	this.minsHand.setAngle(minutes * (360 / 60));
	this.hoursHand.setAngle(hours * (360 / 12));
};